using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.IO;

/// <summary>
/// Creates a namespace for all the server methods and class
/// </summary>
namespace Server
{
    /// <summary>
    /// Main form class
    /// </summary>
    public partial class FormMainServer : Form
    {
        
        private Thread readThread;
        private Socket connectionSocket;
        private NetworkStream socketStream;
        private BinaryReader reader;
        private BinaryWriter writer;

        
        /// <summary>
        /// Creates the form and starts a thread for the server
        /// </summary>
                           
        public FormMainServer()
        {
            InitializeComponent();

            // create a new thread
            readThread = new Thread(new ThreadStart(RunServer));
            // start the thread
            readThread.Start();
            
        }
        /// <summary>
        /// Starts the server up
        /// </summary>
        public void RunServer()
        {
            TcpListener listener;
            int         counter = 1;
   

            // initialize the ip and the port of the server
            Int32 port = 5000;
            IPAddress localAddr = IPAddress.Parse("127.0.0.1");


            //
            try
            {
                //creates a listener for the server
                listener = new TcpListener(localAddr, port);

                //starts the listener
                listener.Start();

                //
                while (true)
                {
                    //updates the user
                    DisplayMessage("Waiting for connection\r\n");

                    //gets the accpeted socket
                    connectionSocket = listener.AcceptSocket();

                    //creates a network stream with the accepted socket
                    socketStream = new NetworkStream(connectionSocket);

                    //create a stream reader and writer
                    writer = new BinaryWriter(socketStream);
                    reader = new BinaryReader(socketStream);

                    DisplayMessage("Connection " + counter + " received.\r\n");

                    //updates the user
                    writer.Write("SERVER>>> Connection succesful ");

                    DisableInput(false); 
                    string replay = "";

                    do
                    {
                        try
                        {
                            //reads from the stream
                            replay = reader.ReadString();

                            //updates the user
                            DisplayMessage("\r\n" + replay);

                        }

                        //catchs any exceptions
                        catch (Exception)
                        {
                            break;
                        }

                    } while (replay != "CLIENT>>> TERMINATE" && connectionSocket.Connected);

                    //updates the user
                    DisplayMessage("\r\nUser terminated connection");

                    //disables the input on the textbox
                    DisableInput(true); // 
                    writer.Close();
                    reader.Close();
                    socketStream.Close();
                    connectionSocket.Close();

                    ++counter;
                   
                }
            }

            catch (Exception error)
            {
                MessageBox.Show(error.ToString());
            }
        }

        //Creates a delegate to be displayed
        private delegate void DisplayDelegate(string message);

        
         /// <summary>
         /// method to display the delegate
         /// </summary>
         /// <param name="message"></param>
        private void DisplayMessage(string message)
        {
            // checks to see if safe call
            if (textBoxMessageDisplayed.InvokeRequired)
            {
                //invokes the methods if invoking is required                              
                Invoke(new DisplayDelegate(DisplayMessage),
                   new object[] { message });
            } // end if
            else // appends to the textbox
                textBoxMessageDisplayed.Text += message;
        } 
 
        // determines if the delegate needs to be  displayed
        private delegate void DisableInputDelegate(bool value);

         
        /// <summary>
        /// Disables input to textbox
        /// </summary>
        /// <param name="value"></param>
        private void DisableInput(bool value)
        {
            // checks if invoke is required for method
            if (textBoxInput.InvokeRequired)
            {
        
                //invokes the method if required                              
                Invoke(new DisableInputDelegate(DisableInput),
                   new object[] { value });
            }
            else // sets the textbox to read only
                textBoxInput.ReadOnly = value;
        }

        /// <summary>
        /// Key listener for the textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
         private void textBoxInputKeyDown(object sender, KeyEventArgs e)
        {

             // checks for valid key entry
            try
            {
                if (e.KeyCode == Keys.Enter && connectionSocket != null)
                {
                    writer.Write("SERVER>>> " + textBoxInput.Text);
                    textBoxMessageDisplayed.Text += "\r\nSERVER>>> " + textBoxInput.Text;

                    //closes connection if terminated
                    if (textBoxInput.Text == "TERMINATE")
                    {
                        connectionSocket.Close();
                    }
                    textBoxInput.Clear();

                }

            }
            catch (SocketException)
            {
                textBoxMessageDisplayed.Text += "\nError waiting object";
            }
        }

        /// <summary>
        /// Method to close connection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ServerClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);                          
        }

        /// <summary>
        /// Method for closing the server
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ServerClosed(object sender, FormClosedEventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);   
        }


    }
}