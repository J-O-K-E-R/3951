using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.IO;

namespace Server
{
    public partial class FormMainServer : Form
    {
        
        private Thread readThread;
        private Socket connectionSocket;
        private NetworkStream socketStream;
        private BinaryReader reader;
        private BinaryWriter writer;

              
        public FormMainServer()
        {
            InitializeComponent();

            // create a new thread
            readThread = new Thread(new ThreadStart(RunServer));
            // start the thread
            readThread.Start();
            
        }

        public void RunServer()
        {
            TcpListener listener;
            int         counter = 1;
   

            // Set the TcpListener on port 5000.
            Int32 port = 5000;
            IPAddress localAddr = IPAddress.Parse("127.0.0.1");


            //wait for a client
            try
            {
                //Step 1: create the TcpListner
                listener = new TcpListener(localAddr, port);

                //Spet 2: TcpListner waits for connection request
                listener.Start();

                //Step 3: establish connection upon request
                while (true)
                {
                    //textBoxMessageDisplayed.Text = "Waiting for connection\r\n";
                    DisplayMessage("Waiting for connection\r\n");

                    //accept an incomming connection
                    connectionSocket = listener.AcceptSocket();

                    //create NetworkStream object associated with socket
                    socketStream = new NetworkStream(connectionSocket);

                    //create objects for transferring data accross streams
                    writer = new BinaryWriter(socketStream);
                    reader = new BinaryReader(socketStream);

                    DisplayMessage("Connection " + counter + " received.\r\n");

                    //inform clent that the connection is succesful
                    writer.Write("SERVER>>> Connection succesful ");

                    DisableInput(false); 
                    string replay = "";

                    do
                    {
                        try
                        {
                            //read the string sent to the server
                            replay = reader.ReadString();

                            //display the message
                            //textBoxMessageDisplayed.Text += "\r\n" + replay;
                            DisplayMessage("\r\n" + replay);

                        }

                        //handle exception if error reading data
                        catch (Exception)
                        {
                            break;
                        }

                    } while (replay != "CLIENT>>> TERMINATE" && connectionSocket.Connected);

                    //textBoxMessageDisplayed.Text += "\r\nUser terminated connection";
                    DisplayMessage("\r\nUser terminated connection");

                    //Step 5: closing the connection
                    DisableInput(true); // makes the text box read/olny again
                    writer.Close();
                    reader.Close();
                    socketStream.Close();
                    connectionSocket.Close();

                    ++counter;
                   
                }
            }// end try

            catch (Exception error)
            {
                MessageBox.Show(error.ToString());
            }
        }// end method RunServer

        // delegate that allows method DisplayMessage to be called
        // in the thread that creates and maintains the GUI       
        private delegate void DisplayDelegate(string message);

        // method DisplayMessage sets displayTextBox's Text property
        // in a thread-safe manner
        private void DisplayMessage(string message)
        {
            // if modifying displayTextBox is not thread safe
            if (textBoxMessageDisplayed.InvokeRequired)
            {
                // use inherited method Invoke to execute DisplayMessage
                // via a delegate                                       
                Invoke(new DisplayDelegate(DisplayMessage),
                   new object[] { message });
            } // end if
            else // OK to modify displayTextBox in current thread
                textBoxMessageDisplayed.Text += message;
        } // end method DisplayMessage

        // delegate that allows method DisableInput to be called 
        // in the thread that creates and maintains the GUI
        private delegate void DisableInputDelegate(bool value);

        // method DisableInput sets textBoxMessageDisplayed's ReadOnly property
        // in a thread-safe manner
        private void DisableInput(bool value)
        {
            // if modifying textBoxMessageDisplayed is not thread safe
            if (textBoxInput.InvokeRequired)
            {
                // use inherited method Invoke to execute DisableInput
                // via a delegate                                     
                Invoke(new DisableInputDelegate(DisableInput),
                   new object[] { value });
            } // end if
            else // OK to modify textBoxMessageDisplayed in current thread
                textBoxInput.ReadOnly = value;
        } // end method DisableInput


         private void textBoxInputKeyDown(object sender, KeyEventArgs e)
        {

             // sends text to the client
            try
            {
                if (e.KeyCode == Keys.Enter && connectionSocket != null)
                {
                    writer.Write("SERVER>>> " + textBoxInput.Text);
                    textBoxMessageDisplayed.Text += "\r\nSERVER>>> " + textBoxInput.Text;

                    //if the server's administrator signals "TERMINATE"
                    if (textBoxInput.Text == "TERMINATE")
                    {
                        connectionSocket.Close();
                    }
                    textBoxInput.Clear();

                }

            }
            catch (SocketException)
            {
                textBoxMessageDisplayed.Text += "\nError waiting object";
            }
        } // textBoxInputKeyDown

        private void ServerClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);                          
        }

        private void ServerClosed(object sender, FormClosedEventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);   
        }


    }
}