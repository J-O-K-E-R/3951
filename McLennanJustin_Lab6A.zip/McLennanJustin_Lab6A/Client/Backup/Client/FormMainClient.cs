using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.IO;

namespace Client
{
    
    public partial class FormMainClient : Form
    {

        private Thread readThread;
        private BinaryReader reader;
        private BinaryWriter writer;
        private NetworkStream outputToServer;
        private string message = "";


        public FormMainClient()
        {
            InitializeComponent();
            // create a new thread
            readThread = new Thread(new ThreadStart(RunClient));
            // start the thread
            readThread.Start();
  
        }

        private void Client_Closing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);                          
        }

        // delegate that allows method DisplayMessage to be called
        // in the thread that creates and maintains the GUI       
        private delegate void DisplayDelegate(string message);

        // method DisplayMessage sets displayTextBox's Text property
        // in a thread-safe manner
        private void DisplayMessage(string message)
        {
            // if modifying displayTextBox is not thread safe
            if (textBoxMessageDisplayed.InvokeRequired)
            {
                // use inherited method Invoke to execute DisplayMessage
                // via a delegate                                       
                Invoke(new DisplayDelegate(DisplayMessage),
                   new object[] { message });
            } // end if
            else // OK to modify displayTextBox in current thread
                textBoxMessageDisplayed.Text += message;
        } // end method DisplayMessage

        // delegate that allows method DisableInput to be called 
        // in the thread that creates and maintains the GUI
        private delegate void DisableInputDelegate(bool value);

        // method DisableInput sets textBoxMessageDisplayed's ReadOnly property
        // in a thread-safe manner
        private void DisableInput(bool value)
        {
            // if modifying textBoxMessageDisplayed is not thread safe
            if (textBoxInput.InvokeRequired)
            {
                // use inherited method Invoke to execute DisableInput
                // via a delegate                                     
                Invoke(new DisableInputDelegate(DisableInput),
                   new object[] { value });
            } // end if
            else // OK to modify textBoxMessageDisplayed in current thread
                textBoxInput.ReadOnly = value;
        } // end method DisableInput


        private void textBoxInputKeyDown(object sender, KeyEventArgs e)
        {
            // sends text to the server
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    if (writer == null)
                        writer = new BinaryWriter(outputToServer);

                    writer.Write("CLIENT>>> " + textBoxInput.Text);
                    textBoxMessageDisplayed.Text += "\r\nCLIENT>>> " + textBoxInput.Text;
                    textBoxInput.Clear();
                }

            }// end try
            catch (SocketException)
            {
                //textBoxMessageDisplayed.Text += "\nError waiting object";
                DisplayMessage("\nError waiting object");
            }

        }// end textBoxInputKeyDown

        public void RunClient()
        {
            TcpClient client;

            //instanciate  TcpClient for sending data to the server
            try
            {
                //textBoxMessageDisplayed.Text += "Attempting connection |r\n";
                DisplayMessage("Attempting connection |r\n");

                //Step 1: Create TcpClient and connect to the server
                client = new TcpClient();
                client.Connect("localhost", 5000);

                //Step 2: get NetworkStream associated with TcpClient
                outputToServer = client.GetStream();

                //create objects for writting and reading across the stream
                writer = new BinaryWriter(outputToServer);
                reader = new BinaryReader(outputToServer);

                //textBoxMessageDisplayed.Text += "\r\nGot I/O streams \r\n";
                DisplayMessage("\r\nGot I/O streams \r\n");

                //textBoxInput.ReadOnly = false;
                DisableInput(false);

                // loop until the server sends the message
                do
                {
                    //Step 3: processing
                    try
                    {
                        //read message from server
                        message = reader.ReadString();
                        //textBoxMessageDisplayed.Text += "\r\n" + message;
                        DisplayMessage("\r\n" + message);

                    }//end try
                    catch (Exception)
                    {
                        System.Environment.Exit(System.Environment.ExitCode);
                    }
                } while (message != "SERVER>>> TERMINATE");

                //textBoxMessageDisplayed.Text += "\r\rClosing connections. \r\n";
                DisplayMessage("\r\rClosing connections. \r\n");
                
                //Step 4: close connections
                writer.Close();
                reader.Close();
                outputToServer.Close();
                client.Close();
                Application.Exit();
            }// end try
            catch (Exception error)
            {
                MessageBox.Show(error.ToString() );
            }


        }// end RunClient()

    }
}