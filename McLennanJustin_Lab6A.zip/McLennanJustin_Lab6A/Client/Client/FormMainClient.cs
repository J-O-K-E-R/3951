using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using System.IO;

/// <summary>
/// This is the client namespace
/// Within we have all methods for the client side 
/// </summary>
namespace Client
{
    /// <summary>
    /// Main form class
    /// </summary>
    public partial class FormMainClient : Form
    {

        private Thread readThread;
        private BinaryReader reader;
        private BinaryWriter writer;
        private NetworkStream outputToServer;
        private string message = "";

        /// <summary>
        /// Initialize the form here and create & start a new thread
        /// </summary>
        public FormMainClient()
        {
            InitializeComponent();
            // 
            readThread = new Thread(new ThreadStart(RunClient));
            // 
            readThread.Start();
  
        }

        private void Client_Closing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(System.Environment.ExitCode);                          
        }

        // Create the delegate to be displayed       
        private delegate void DisplayDelegate(string message);

        // Method called to dispaly the delegate
        private void DisplayMessage(string message)
        {
            // Allows us to make thread safe calls
            if (textBoxMessageDisplayed.InvokeRequired)
            {
                //Makes a call to the tread to dispaly delegate                                        
                Invoke(new DisplayDelegate(DisplayMessage),
                   new object[] { message });
            }
            else // Adds to the text box if call is unsafe
                textBoxMessageDisplayed.Text += message;
        }

        // This determines if the delegate needs to be displayed
        private delegate void DisableInputDelegate(bool value);

        
        /// <summary>
        /// Disables the input of the textbox / readonly
        /// </summary>
        /// <param name="value"></param>
        private void DisableInput(bool value)
        {
            // Checks if a invoke is required to call method
            if (textBoxInput.InvokeRequired)
            {
                //calls method if invoke is required                              
                Invoke(new DisableInputDelegate(DisableInput),
                   new object[] { value });
            } 
            else //sets the text box as read only 
                textBoxInput.ReadOnly = value;
        } // 

        /// <summary>
        /// Add key listeners to the textbox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void textBoxInputKeyDown(object sender, KeyEventArgs e)
        {
            //try for the enter key
            try
            {
                if (e.KeyCode == Keys.Enter)
                {
                    if (writer == null)
                        writer = new BinaryWriter(outputToServer);

                    writer.Write("CLIENT>>> " + textBoxInput.Text);
                    textBoxMessageDisplayed.Text += "\r\nCLIENT>>> " + textBoxInput.Text;
                    textBoxInput.Clear();
                }

            }// end try
            catch (SocketException)
            {
                //Error print out
                DisplayMessage("\nError waiting object");
            }

        }

        /// <summary>
        /// Runs the client when a connection is tried
        /// </summary>
        public void RunClient()
        {
            TcpClient client;

            //check if able to connect
            try
            {
                // updates the user
                DisplayMessage("Attempting connection \r\n");

                //sets up connection
                client = new TcpClient();
                client.Connect("localhost", 5000);

                //gets the client stream
                outputToServer = client.GetStream();

                //create new write and readers
                writer = new BinaryWriter(outputToServer);
                reader = new BinaryReader(outputToServer);

                //updates the user
                DisplayMessage("\r\nGot I/O streams \r\n");

                //disables the textbox
                DisableInput(false);

                do
                {
                    //attempts to read
                    try
                    {
                        //get message from the reader 
                        message = reader.ReadString();
                        //displays the message
                        DisplayMessage("\r\n" + message);

                    }//catches exiting
                    catch (Exception)
                    {
                        System.Environment.Exit(System.Environment.ExitCode);
                    }
                } while (message != "SERVER>>> TERMINATE");

                //updates the user
                DisplayMessage("\r\rClosing connections. \r\n");
                
                //closes all streams
                writer.Close();
                reader.Close();
                outputToServer.Close();
                client.Close();
                Application.Exit();
            }//Prints out the error 
            catch (Exception error)
            {
                MessageBox.Show(error.ToString() );
            }


        }

    }
}